#!/bin/sh
# 启动的时候生成 flag
echo $FLAG > /root/flag
# webshell 下看不到 flag 内容
chmod 600 /root/flag
# 给予用户 xxd 命令使用权限
chmod 777 /usr/bin/xxd
# 想要看 flag 内容, 通过执行命令 xxd "/root/flag" | xxd -r 来完成
chmod +s /usr/bin/xxd

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh
rm -rf /var/www/html/php.ini
rm -rf /var/www/html/xxd

/etc/init.d/apache2 restart
# 防止container启动后退出
/usr/bin/tail -f /dev/null