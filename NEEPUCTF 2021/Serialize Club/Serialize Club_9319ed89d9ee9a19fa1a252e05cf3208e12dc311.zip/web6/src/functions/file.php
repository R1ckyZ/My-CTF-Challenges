<?php
/**
 *	@author: Ricky
 *	@function: Read file
 *	@return string
 *	@param $filename string
 *  @param $dirname string
 **/

header('content-type:image/jpeg');
$filename = $_GET['file'];
$dirname = '/var/www/html/';
if(!preg_match('/^\/|\/$|\.\//', $filename)){
    $file = file_get_contents($dirname.$filename);
    echo $file;
} else{
    die('Read fail :(');
}