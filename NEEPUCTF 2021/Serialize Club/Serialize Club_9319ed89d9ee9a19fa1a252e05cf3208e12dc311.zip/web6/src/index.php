<!DOCTYPE HTML>
<html>
<head>
    <title>Serailize Club</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="" />
    <!-- css files -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <!-- Preloder css -->
    <link rel="stylesheet" href="css/preloder.css" media="all" />
    <!-- /css files -->
    <!-- font files -->
    <!-- /font files -->
    <!-- js files -->
    <script src="js/modernizr.custom.js"></script>
    <!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<!-- loader-wrapper -->
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- end loader-wrapper -->
<div class="navbar-wrapper">
    <div class="container">
        <nav class="navbar navbar-inverse navbar-static-top cl-effect-20">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <?php
                    error_reporting(0);
                    include "config/backdoor.php";
                    ini_set('session.serialize_handler','php');
                    session_start();
                    class neepu {
                        protected
                            //! Neepu
                            $neepu,
                            //! Memory-held data
                            $data,
                            //! Info
                            $info;

                        public function __construct() {
                            $this->neepu = "<a class=\"navbar-brand\" href=\"index.php\">Serialize</a>";
                            $this->info['info'] = "<a class=\"navbar-brand\" href=\"index.php\">PHPINFO</a>";
                        }

                        public function checkinfo() {
                            if(!isset($_POST['info'])) {
                                echo $this->neepu;
                            }else {
                                echo $this->info['info'];
                                phpinfo();
                            }
                        }

                        public function __call($name,$args) {
                            echo $this->neepu;
                        }

                        public function __toString() {
                            $this->info['info']->data;
                            return "Neepu!";
                        }
                    }
                    class n33pu {
                        public
                            //! Neepu func
                            $func;

                        public function __get($args) {
                            $Neepu = $this->func;
                            return $Neepu();
                        }
                    }
                    class dumb {
                        public
                            //! dumb
                            $dumb;

                        public function silly(){
                            echo "Who care about it?";
                        }

                        public function __destruct(){
                            $this->dumb->silly();
                        }
                    }
                    $Neepu = new neepu();
                    echo $Neepu->checkinfo();
                    ?>
                </div>
                <div id="navbar" class="navbar-collapse collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="#"><span data-hover="To">Welcome</span></a></li>
                        <li><a href="#"><span data-hover="our">come to</span></a></li>
                        <li><a href="#"><span data-hover="beloved">Serialize</span></a></li>
                        <li><a href="#about"><span data-hover="master">Club ~</span></a></li>
                        <li><a href="#"><span data-hover="in">My</span></a></li>
                        <li><a href="#"><span data-hover="Serialize">darlings</span></a></li>
                        <li><a href="#events"><span data-hover="Club">friends</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Banner Section -->
<!-- Carousel
    ================================================== -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img class="first-slide" src="functions/file.php?file=images/banner1.jpg" alt="First slide">
        </div>
        <div class="item">
            <img class="second-slide" src="functions/file.php?file=images/banner2.jpg" alt="Second slide">
        </div>
        <div class="item">
            <img class="third-slide" src="functions/file.php?file=images/banner3.jpg" alt="Third slide">
        </div>
    </div>
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div><!-- /.carousel -->
<!-- /Banner Section -->
<!-- About Section -->
<section class="about-us" id="about">
    <h3 class="text-center slideanim">Seralize Club</h3>
    <p class="text-center slideanim"> Produces a representation of a storable value</p>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <img src="functions/file.php?file=images/about-img.jpg" alt="about" class="img-responsive slideanim">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="about-info">
                    <h4 class="slideanim">Serialize is our best friend</h4>
                    <p class="abt slideanim"> I have also written some code for importing serialized PHP data into PERL and then writing it back into PHP.  I think the similar library posted above is actually more robust for a few select cases, but mine is more compact and a little easier to follow.  I'd really like comments if anyone finds this useful or has improvements.  Please credit me if you use my code.</p>
                    <p class="abt slideanim"> I was trying to submit a serialized array through a hidden form field using POST and was having a lot of trouble with the quotes. I couldn't figure out a way to escape the quotes in the string so that they'd show up right inside the form, so only the characters up to the first set of quotes were being sent.</p>
                    <p class="abt slideanim"> My solution was to base64_encode() the string, put that in the hidden form field, and send that through the POST method. Then I decoded it (using base64_decode()) on the other end. This seemed to solve the problem.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /About Section -->
<!-- Events -->
<section class="our-events slideanim" id="events">
    <h3 class="text-center slideanim">Our Objects</h3>
    <p class="text-center slideanim"> Serialize in WEB</p>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <div class="event-info">
                    <h4 class="text-center slideanim">Users data</h4>
                    <p class="eve slideanim"> &lt;?php</p>
                    <p class="eve slideanim"> class user {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic $user = 'ricky';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic $school = 'neepu';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic function __destruct() {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspecho $this->user.' like neepu!';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp}</p>
                    <p class="eve slideanim"> }</p>
                    <p class="eve slideanim"> </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="event-info">
                    <h4 class="text-center slideanim">Password Save</h4>
                    <p class="eve slideanim"> &lt;?php</p>
                    <p class="eve slideanim"> class config {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic $username = 'Neepu';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic $password = 'neepu';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbspfunction save($password) {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$secret=md5($password);</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp}</p>
                    <p class="eve slideanim"> }</p>
                    <p class="eve slideanim"> </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="event-info">
                    <h4 class="text-center slideanim">CTF FLAG</h4>
                    <p class="eve slideanim"> &lt;?php</p>
                    <p class="eve slideanim"> class Neepu {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbspprotected $FLAG = 'Neepu{flag}';</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsppublic $I_Want_A_FLAG;</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbspfunction flag($FLAG) {</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$I_Want_A_FLAG = $FLAG;</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspecho $I_Want_A_FLAG;</p>
                    <p class="eve slideanim"> &nbsp&nbsp&nbsp&nbsp}</p>
                    <p class="eve slideanim"> }</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Events -->
<!-- Footer Section -->
<section class="footer">
    <h2 class="text-center">WELCOME TO JOIN US</h2>
    <div class="copyright">
        <p>Copyright &copy; 2021.We all love discussing with Serialize.</p>
    </div>
</section>
<!-- /Footer Section -->
<!-- Back To Top -->
<a href="#0" class="cd-top">Top</a>
<!-- /Back To Top -->

<!-- js files -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/SmoothScroll.min.js"></script>
<!-- js for gallery -->
<script src="js/darkbox.js"></script>
<!-- /js for gallery -->
<!-- js for back to top -->
<script src="js/main.js"></script>
<!-- /js for back to top -->
<!-- js for nav-smooth scroll -->
<script>
    $(document).ready(function(){
        // Add smooth scrolling to all links in navbar + footer link
        $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 900, function(){

                // Add hash (#) to URL when done scrolling (default click behavior)
                window.location.hash = hash;
            });
        });
    })
</script>
<!-- /js for nav-smooth scroll -->
<!-- js for slide animations -->
<script>
    $(window).scroll(function() {
        $(".slideanim").each(function(){
            var pos = $(this).offset().top;

            var winTop = $(window).scrollTop();
            if (pos < winTop + 600) {
                $(this).addClass("slide");
            }
        });
    });
</script>
<script src="js/jquery-1.9.1.min.js"></script>	              	<!-- Main js file -->
<script src="js/custom.js"></script>						   	<!-- Custom js file -->
<!-- /js for slide animations -->
<!-- /js files -->
<style>
.copyrights{text-indent:-9999px;height:0;line-height:0;font-size:0;overflow:hidden;}
</style>
</body>
</html>
