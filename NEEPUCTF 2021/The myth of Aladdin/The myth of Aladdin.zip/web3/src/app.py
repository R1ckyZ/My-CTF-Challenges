import subprocess
from flask import request
from flask import redirect
from flask import url_for
from flask import render_template_string
from flask import render_template
from flask import Flask
import re


app = Flask(__name__)
template = """
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="static/stylesheets/style.css">
	</head>
		<body>
			<title>The myth of Aladdin</title>
			<h1>The greatest Aladdin</h1>
			<div id="wish" class="wish">
				<form method="POST">
				<input type="text" placeholder="I want a girlfriend" name="wish">
				</form>
			</div>
			<div id="msg" class="msg">
			{}
			</div>
		</body>
	<script src="static/javascripts/jquery-1.11.0.min.js"></script>
	</script><script src="static/javascripts/index.js"></script>
</html>
"""

@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        wish = request.form['wish']
        if 'girl' in wish:
            return render_template("girl.html")
        if wish:
            if re.search(r"\{\{| |\$|\'|\`|\<|\>|\:|\;|\+|\*|\||class|base|mro|\_|config|args|init|global|\.|req|\|attr|get|lipsum|count|dict|eval|exec|os|popen|read|select|url_for|\\x|length|request|get_flashed_messages|cat|tac|nl|curl|cut|flag", wish, re.I):
                return template.format("The greatest Aladdin, I want a girlfriend!")
        if 'Neepu{' in render_template_string(wish):
            return template.format("<img src=\"static/stylesheets/images/flag.jpg\" title=\"flag\" width=\"20%\">")
        return render_template_string(template.format("Your wish is : " + wish))
    else:
        return render_template("index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0")
