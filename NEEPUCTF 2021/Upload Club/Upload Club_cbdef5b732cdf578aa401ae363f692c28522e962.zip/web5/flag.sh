#!/bin/sh
# 启动的时候生成 flag
echo $FLAG > /flag
# webshell 下看不到 flag 内容
chmod 600 /flag
# 给予用户/getflag 使用权限
chmod 777 /getflag
# 想要看 flag 内容, 通过执行命令 /getflag 来完成
chmod +s /getflag

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh
rm -rf /var/www/html/php.ini

/etc/init.d/apache2 restart
# 防止container启动后退出
/usr/bin/tail -f /dev/null